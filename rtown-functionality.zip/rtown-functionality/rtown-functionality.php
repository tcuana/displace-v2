<?php
/**
 * Plugin Name: RTOWN Functionality
 * Author: RTOWN
 * Author URI: https://rtown.ca/
 * Version: 1.0
 * License: GPL v2
 */

/** Custom Login Page Styles **/

function my_login_logo() { ?>
  <style type="text/css">
      #login h1 a, .login h1 a {
        background: url(<?php echo plugins_url( 'images/RTOWN_Logo_White.png', __FILE__ ) ?>);
        padding-bottom: 30px;
        background-size: 300px !important; width: 300px !important;
        background-position: bottom !important;
      }
      .login #backtoblog a, .login #nav a {
        color: #fff !important;
      }
      body.login {  
        background: #27aae1; 
      }
  </style>
<?php }

/** Custom Login Logo URL **/

add_action( 'login_enqueue_scripts', 'my_login_logo' );

function my_login_logo_url() {
return "https://rtown.ca/";
}
add_filter( 'login_headerurl', 'my_login_logo_url' );
